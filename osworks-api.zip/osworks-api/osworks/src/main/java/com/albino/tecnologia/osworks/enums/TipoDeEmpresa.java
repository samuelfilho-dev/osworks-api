package com.albino.tecnologia.osworks.enums;

public enum TipoDeEmpresa {
    CLIENTE,
    FORNECEDOR
}
