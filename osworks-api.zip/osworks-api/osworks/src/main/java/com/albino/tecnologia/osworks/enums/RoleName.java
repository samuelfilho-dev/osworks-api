package com.albino.tecnologia.osworks.enums;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_GPP,
    ROLE_FINANCEIRO,
    ROLE_DIRETOR,
    ROLE_GP

}
