package com.albino.tecnologia.osworks.enums;

public enum TipoDeContrato {

    PRODUTO,
    SERVICO
}
