package com.albino.tecnologia.osworks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OsworksApplicationTests {

	@Test
	void contextLoads() {

	}

}
